/*
	Assignment 12
	jQuery
	WEB230
	{your name here}
*/

$(document).ready(function(){



});
